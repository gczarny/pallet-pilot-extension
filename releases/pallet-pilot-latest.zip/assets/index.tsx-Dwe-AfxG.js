import{u as V,r as m,s as k,j as e,f as P,c as R,d as Y,I as K}from"./index--Y47qI15.js";import{g as C,J as Q,i as X}from"./index-pOXOa4sX.js";import"./_commonjsHelpers-Cpj98o6Y.js";async function Z(a,c,o){const r=C(a);if(!r?.getBidsApiConfig)return console.log("[fetchBids] No adapter or getBidsApiConfig for URL:",a),[];let p;r instanceof Q&&(p=r.extractBidsActionId(document),console.log("[fetchBids] Extracted action ID:",p));const l=r.getBidsApiConfig(a,{currency:c,language:o,bidsActionId:p});if(!l)return console.log("[fetchBids] No bids config returned"),[];console.log("[fetchBids] Fetching bids from:",l.url,"method:",l.method);try{const f=await fetch(l.url,{method:l.method,headers:l.headers,body:l.method==="POST"?l.body:void 0,credentials:"include"});if(!f.ok)return console.error("[fetchBids] Response not OK:",f.status),[];const h=await f.text();return console.log("[fetchBids] Response length:",h.length,"first 300 chars:",h.slice(0,300)),ee(h)}catch(f){return console.error("[fetchBids] Fetch error:",f),[]}}function ee(a){const c=o=>({id:o.id,auctionId:o.auction_id,userId:o.user_id,userName:o.user_details?.username||o.user_details?.name||"Unknown",bidPrice:o.bid_price,bidTime:o.bid_time,currencyId:o.currency_id,isAutoBid:o.is_auto_bid===1});try{try{const r=JSON.parse(a);if(Array.isArray(r))return r.map(c);if(r.bid&&Array.isArray(r.bid))return r.bid.map(c);if(r.result?.bid&&Array.isArray(r.result.bid))return r.result.bid.map(c);if(r.data&&Array.isArray(r.data))return r.data.map(c)}catch{}const o=a.split(`
`);for(const r of o){const p=r.match(/^\d+:(\{.+\})$/);if(p)try{const l=JSON.parse(p[1]);if(l.result?.bid&&Array.isArray(l.result.bid))return console.log("[fetchBids] Found bids in RSC format:",l.result.bid.length),l.result.bid.map(c)}catch{}}return console.log("[fetchBids] Could not parse bids from response"),[]}catch(o){return console.error("[fetchBids] Failed to parse bids response:",o),[]}}function te({url:a,sku:c,analysis:o,isLoading:r,onAnalysisComplete:p,onRefresh:l,competitorCheck:f,hasCheckedBids:h,onCompetitorCheckComplete:w}){const{t:s}=V(),[L,B]=m.useState(!1),[x,j]=m.useState(null),[v,O]=m.useState(!1),[u,A]=m.useState(!1),[N,D]=m.useState(null);m.useEffect(()=>{if(o&&!h&&!u){const t=C(a)?.scrapePageData(document)??{};E(t.currency,t.language)}},[o,h]);const E=async(i,t)=>{A(!0);try{const n=await k({type:"GET_WATCHLIST"});if(!n.success){console.error("[Panel] Failed to get watchlist"),w(null);return}const d=n.data.watchlist;if(d.length===0){console.log("[Panel] Watchlist empty, skipping bid check"),w(null);return}const y=await Z(a,i,t);console.log("[Panel] Fetched bids:",y.length);const T=d.map(b=>b.odlerId.toLowerCase());console.log("[Panel] Checking against watchlist:",T);const U=y.filter(b=>{const _=String(b.userId).toLowerCase(),F=b.userName.toLowerCase();return T.includes(_)||T.includes(F)}).map(b=>{const _=String(b.userId).toLowerCase(),F=b.userName.toLowerCase(),W=d.find(J=>{const M=J.odlerId.toLowerCase();return M===_||M===F});return{bid:b,watchlistName:W?.name||void 0}}),$=y.length>0?y[0]:void 0;w({hasCompetitorBids:U.length>0,competitorBids:U,totalBids:y.length,highestBid:$})}catch(n){console.error("[Panel] Failed to check competitor bids:",n),w(null)}finally{A(!1)}},S=async()=>{B(!0),j(null);const t=C(a)?.scrapePageData(document)??{};try{const n=await k({type:"DOWNLOAD_AND_ANALYZE_MANIFEST",payload:{url:a,sku:c,title:t.title,imageUrl:t.imageUrl,currency:t.currency,language:t.language,isAuctionEnded:t.isAuctionEnded}});n.success?(p(n.data.analysis),E(t.currency,t.language)):j(n.error.message)}catch(n){j(n instanceof Error?n.message:s("common.unknownError"))}finally{B(!1)}},H=async()=>{if(!o)return;let i=o.currency;if(!i){const d=await k({type:"GET_SETTINGS"});i=d.success?d.data.settings.defaultCurrency:"PLN"}const t=prompt(s("fab.enterPrice",{currency:i}));if(!t)return;const n=parseFloat(t.replace(",","."));if(isNaN(n)||n<=0){alert(s("fab.invalidPrice"));return}try{const d=await k({type:"SAVE_PURCHASE",payload:{analysisId:o.id,purchasePrice:n}});d.success?l():alert(s("common.error")+": "+d.error.message)}catch{alert(s("fab.saveError"))}};if(r)return e.jsx("div",{className:"panel",children:e.jsxs("div",{className:"loading",children:[e.jsx("div",{className:"spinner"}),e.jsx("p",{children:s("common.loading")})]})});if(L)return e.jsxs("div",{className:"panel",children:[e.jsxs("div",{className:"panel-header",children:[e.jsx("h3",{children:s("fab.title")}),e.jsxs("p",{children:[s("fab.sku"),": ",c]})]}),e.jsxs("div",{className:"loading",children:[e.jsx("div",{className:"spinner"}),e.jsx("p",{children:s("fab.downloadingManifest")})]})]});if(!o)return e.jsxs("div",{className:"panel",children:[e.jsxs("div",{className:"panel-header",children:[e.jsx("h3",{children:s("fab.title")}),e.jsxs("p",{children:[s("fab.sku"),": ",c]})]}),e.jsxs("div",{className:"panel-content",children:[x&&e.jsx("div",{className:"error",children:x}),e.jsx("p",{style:{marginBottom:"16px",color:"#64748b",fontSize:"13px"},children:s("fab.downloadHint")}),e.jsx("button",{className:"btn btn-primary",onClick:S,children:s("fab.downloadManifest")})]})]});const{summary:g}=o,I=o.currency||"PLN";return e.jsxs("div",{className:"panel",children:[e.jsxs("div",{className:"panel-header",children:[e.jsx("h3",{children:o.title?o.title.slice(0,60)+(o.title.length>60?"...":""):s("fab.title")}),e.jsxs("p",{children:[s("fab.sku"),": ",c,o.status==="purchased"&&` • ${s("fab.purchased")}`]})]}),e.jsxs("div",{className:"panel-content",children:[x&&e.jsx("div",{className:"error",children:x}),u&&e.jsx("div",{className:"competitor-checking",children:s("fab.competitors.checking")}),f?.hasCompetitorBids&&(()=>{const i=f.competitorBids.reduce((t,n)=>{const d=n.watchlistName||n.bid.userName;return t[d]||(t[d]=[]),t[d].push(n.bid),t},{});return e.jsxs("div",{className:"competitor-warning",children:[e.jsxs("div",{className:"competitor-warning-title",children:[s("fab.competitors.warningTitle")," (",Object.keys(i).length,")"]}),e.jsx("div",{className:"competitor-users",children:Object.entries(i).map(([t,n])=>e.jsxs("div",{className:"competitor-user",children:[e.jsxs("button",{className:"competitor-user-header",onClick:()=>D(N===t?null:t),children:[e.jsx("span",{className:"competitor-name",children:t}),e.jsxs("span",{className:"competitor-bid-count",children:[n.length," ",n.length===1?s("fab.competitors.offer"):s("fab.competitors.offers"),e.jsx("span",{className:"competitor-expand-icon",children:N===t?"▼":"▶"})]})]}),N===t&&e.jsx("div",{className:"competitor-bids-list",children:n.map((d,y)=>e.jsxs("div",{className:"competitor-bid",children:[e.jsx("span",{className:"competitor-bid-time",children:new Date(d.bidTime).toLocaleString(void 0,{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"})}),e.jsxs("span",{className:"competitor-price",children:[Number(d.bidPrice).toFixed(2)," ",I]})]},y))})]},t))})]})})(),e.jsxs("div",{className:"stat-grid",children:[e.jsxs("div",{className:"stat-item",children:[e.jsx("div",{className:"stat-label",children:s("fab.stats.products")}),e.jsx("div",{className:"stat-value",children:P(g.totalProducts)})]}),e.jsxs("div",{className:"stat-item",children:[e.jsx("div",{className:"stat-label",children:s("fab.stats.items")}),e.jsx("div",{className:"stat-value",children:P(g.totalQuantity)})]}),e.jsxs("div",{className:"stat-item",children:[e.jsx("div",{className:"stat-label",children:s("fab.stats.retailValue")}),e.jsx("div",{className:"stat-value",children:R(g.estimatedValue,I)})]}),e.jsxs("div",{className:"stat-item",children:[e.jsx("div",{className:"stat-label",children:s("fab.stats.avgPrice")}),e.jsx("div",{className:"stat-value",children:R(g.avgPrice,I)})]})]}),g.categoryBreakdown&&Object.keys(g.categoryBreakdown).length>0&&e.jsxs("div",{className:"breakdown",children:[e.jsxs("div",{className:"breakdown-label",children:[s("fab.categories"),":"]}),e.jsxs("div",{className:"breakdown-list",children:[Object.entries(g.categoryBreakdown).sort((i,t)=>{const n=typeof i[1]=="number"?i[1]:i[1].quantity;return(typeof t[1]=="number"?t[1]:t[1].quantity)-n}).slice(0,v?void 0:5).map(([i,t])=>{const n=typeof t=="number"?t:t.quantity,d=typeof t=="number"?null:t.value;return e.jsxs("div",{className:"breakdown-item",children:[e.jsx("span",{className:"breakdown-name",children:i}),e.jsxs("span",{className:"breakdown-value",children:[P(n)," ",s("fab.units"),d!==null&&d>0&&e.jsxs("span",{className:"breakdown-subvalue",children:[" (",R(d,I),")"]})]})]},i)}),Object.keys(g.categoryBreakdown).length>5&&e.jsx("button",{className:"breakdown-item breakdown-more breakdown-toggle",onClick:()=>O(!v),children:v?s("fab.showLess"):s("fab.showMore",{count:Object.keys(g.categoryBreakdown).length-5})})]})]}),g.conditionBreakdown&&Object.keys(g.conditionBreakdown).length>0&&e.jsxs("div",{className:"breakdown",children:[e.jsxs("div",{className:"breakdown-label",children:[s("fab.productCondition"),":"]}),e.jsx("div",{className:"breakdown-list",children:Object.entries(g.conditionBreakdown).sort((i,t)=>t[1]-i[1]).map(([i,t])=>e.jsxs("div",{className:"breakdown-item",children:[e.jsx("span",{className:"breakdown-name",children:i}),e.jsxs("span",{className:"breakdown-value",children:[P(t)," ",s("fab.units")]})]},i))})]}),o.status!=="purchased"&&e.jsx("button",{className:"btn btn-primary",onClick:H,children:s("fab.markAsPurchased")}),e.jsx("button",{className:"btn btn-secondary",onClick:()=>{const t=C(a)?.scrapePageData(document)??{};E(t.currency,t.language)},disabled:u,children:s(u?"fab.competitors.checking":"fab.competitors.checkButton")}),e.jsx("button",{className:"btn btn-secondary",onClick:S,children:s("fab.refreshManifest")})]})]})}function se(a){try{const c=new URL(a);return`${c.origin}${c.pathname}`}catch{return a}}function oe({url:a,sku:c}){const[o,r]=m.useState(!1),[p,l]=m.useState(null),[f,h]=m.useState(!0),[w,s]=m.useState(null),[L,B]=m.useState(!1),x=se(a);m.useEffect(()=>{j()},[x]);const j=m.useCallback(async()=>{h(!0);try{const u=await k({type:"GET_ANALYSIS_FOR_URL",payload:{url:x}});u.success&&u.data.analysis&&l(u.data.analysis)}catch(u){console.error("[FAB] Error loading analysis:",u)}finally{h(!1)}},[x]),v=m.useCallback(u=>{l(u)},[]),O=()=>{r(!o)};return m.useEffect(()=>{if(!o)return;const u=N=>{N.composedPath().some(S=>S instanceof Element&&S.id==="manifest-scout-mount")||r(!1)},A=setTimeout(()=>{document.addEventListener("click",u)},0);return()=>{clearTimeout(A),document.removeEventListener("click",u)}},[o]),e.jsxs("div",{className:"fab-container",children:[e.jsxs("button",{className:"fab-button",onClick:O,title:"Pallet Pilot",children:[e.jsx("img",{src:chrome.runtime.getURL("icons/icon-48.png"),alt:"Pallet Pilot",className:"fab-icon"}),p&&e.jsx("div",{className:"fab-badge",children:p.status==="purchased"?e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"}),e.jsx("line",{x1:"3",y1:"6",x2:"21",y2:"6"}),e.jsx("path",{d:"M16 10a4 4 0 0 1-8 0"})]}):e.jsx("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("polyline",{points:"20 6 9 17 4 12"})})})]}),o&&e.jsx(te,{url:x,sku:c,analysis:p,isLoading:f,onAnalysisComplete:v,onRefresh:j,competitorCheck:w,hasCheckedBids:L,onCompetitorCheckComplete:u=>{s(u),B(!0)}})]})}X();const z=window.location.href,G=C(z);G&&ne(G);async function ne(a){if(!a)return;console.log("[ContentScript] Initializing on product page:",z,"adapter:",a.id);const c=await k({type:"GET_SETTINGS"});if(!c.success||!c.data.settings.extensionEnabled){console.log("[ContentScript] Extension disabled, not injecting FAB");return}const o=c.data.settings,r=a.extractSku(z);if(!r){console.error("[ContentScript] Could not extract SKU from URL");return}const p=document.createElement("div");p.id="manifest-scout-root",document.body.appendChild(p);const l=p.attachShadow({mode:"open"}),f=document.createElement("style");f.textContent=q(o.ui.fabPosition),l.appendChild(f);const h=document.createElement("div");h.id="manifest-scout-mount",l.appendChild(h),Y.createRoot(h).render(e.jsx(m.StrictMode,{children:e.jsx(K,{children:e.jsx(oe,{url:z,sku:r})})})),chrome.runtime.onMessage.addListener(s=>{s.type==="EXTENSION_STATE_CHANGED"&&(s.payload.enabled||p.remove()),s.type==="FAB_POSITION_CHANGED"&&(f.textContent=q(s.payload.position))})}function q(a="right"){return`
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    .fab-container {
      position: fixed;
      ${a==="left"?"left: 16px;":"right: 16px;"}
      top: 50%;
      transform: translateY(-50%);
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
    }

    .fab-button {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
      transition: transform 0.2s, box-shadow 0.2s;
    }

    .fab-button:hover {
      transform: scale(1.05);
      box-shadow: 0 6px 16px rgba(102, 126, 234, 0.5);
    }

    .fab-button svg {
      width: 24px;
      height: 24px;
      color: white;
    }

    .fab-icon {
      width: 32px;
      height: 32px;
      object-fit: contain;
    }

    .fab-badge {
      position: absolute;
      top: -4px;
      right: -4px;
      width: 20px;
      height: 20px;
      border-radius: 50%;
      background: #10b981;
      display: flex;
      align-items: center;
      justify-content: center;
      border: 2px solid white;
    }

    .fab-badge svg {
      width: 12px;
      height: 12px;
      color: white;
    }

    .panel {
      position: fixed;
      ${a==="left"?"left: 80px;":"right: 80px;"}
      top: 50%;
      transform: translateY(-50%);
      width: 320px;
      background: white;
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
      overflow: hidden;
      z-index: 999998;
    }

    .panel-header {
      padding: 16px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
    }

    .panel-header h3 {
      font-size: 16px;
      font-weight: 600;
      margin-bottom: 4px;
    }

    .panel-header p {
      font-size: 12px;
      opacity: 0.9;
    }

    .panel-content {
      padding: 16px;
    }

    .stat-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
      margin-bottom: 16px;
    }

    .stat-item {
      background: #f8fafc;
      padding: 12px;
      border-radius: 8px;
    }

    .stat-label {
      font-size: 11px;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 4px;
    }

    .stat-value {
      font-size: 18px;
      font-weight: 600;
      color: #1e293b;
    }

    .btn {
      width: 100%;
      padding: 12px 16px;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.2s;
      border: none;
    }

    .btn-primary {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
    }

    .btn-primary:hover {
      opacity: 0.9;
    }

    .btn-primary:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }

    .btn-secondary {
      background: #f1f5f9;
      color: #475569;
      margin-top: 8px;
    }

    .btn-secondary:hover {
      background: #e2e8f0;
    }

    .loading {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 24px;
    }

    .spinner {
      width: 32px;
      height: 32px;
      border: 3px solid #e2e8f0;
      border-top-color: #667eea;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .loading p {
      margin-top: 12px;
      color: #64748b;
      font-size: 14px;
    }

    .error {
      background: #fef2f2;
      color: #dc2626;
      padding: 12px;
      border-radius: 8px;
      font-size: 13px;
      margin-bottom: 12px;
    }

    .categories {
      margin-top: 12px;
    }

    .categories-label {
      font-size: 12px;
      color: #64748b;
      margin-bottom: 6px;
    }

    .categories-list {
      display: flex;
      flex-wrap: wrap;
      gap: 4px;
    }

    .category-tag {
      background: #e0e7ff;
      color: #4338ca;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 11px;
    }

    .breakdown {
      margin-top: 16px;
      padding-top: 12px;
      border-top: 1px solid #e2e8f0;
    }

    .breakdown-label {
      font-size: 12px;
      font-weight: 600;
      color: #475569;
      margin-bottom: 8px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .breakdown-list {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }

    .breakdown-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 13px;
      padding: 6px 8px;
      background: #f8fafc;
      border-radius: 6px;
    }

    .breakdown-name {
      color: #334155;
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      margin-right: 8px;
    }

    .breakdown-value {
      color: #667eea;
      font-weight: 600;
      white-space: nowrap;
    }

    .breakdown-more {
      color: #94a3b8;
      font-style: italic;
      justify-content: center;
    }

    .breakdown-toggle {
      cursor: pointer;
      border: none;
      background: #f1f5f9;
      color: #667eea;
      font-style: normal;
      font-weight: 500;
      transition: background 0.2s;
    }

    .breakdown-toggle:hover {
      background: #e2e8f0;
    }

    .breakdown-subvalue {
      color: #94a3b8;
      font-weight: 400;
      font-size: 11px;
    }

    .competitor-checking {
      background: #f0f9ff;
      color: #0369a1;
      padding: 8px 12px;
      border-radius: 8px;
      font-size: 12px;
      margin-bottom: 12px;
      text-align: center;
    }

    .competitor-warning {
      background: #fef2f2;
      border: 1px solid #fecaca;
      border-radius: 8px;
      padding: 12px;
      margin-bottom: 12px;
    }

    .competitor-warning-title {
      color: #dc2626;
      font-weight: 600;
      font-size: 13px;
      margin-bottom: 8px;
    }

    .competitor-users {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }

    .competitor-user {
      background: white;
      border-radius: 6px;
      overflow: hidden;
    }

    .competitor-user-header {
      width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 8px 10px;
      border: none;
      background: transparent;
      cursor: pointer;
      font-size: 12px;
      transition: background 0.15s;
    }

    .competitor-user-header:hover {
      background: #fef2f2;
    }

    .competitor-name {
      color: #991b1b;
      font-weight: 600;
    }

    .competitor-bid-count {
      color: #dc2626;
      font-size: 11px;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .competitor-expand-icon {
      font-size: 9px;
      color: #9ca3af;
    }

    .competitor-bids-list {
      display: flex;
      flex-direction: column;
      gap: 2px;
      padding: 0 8px 8px 8px;
      max-height: 90px;
      overflow-y: auto;
    }

    .competitor-bid {
      display: flex;
      justify-content: space-between;
      font-size: 11px;
      padding: 4px 8px;
      background: #fef2f2;
      border-radius: 4px;
    }

    .competitor-bid-time {
      color: #6b7280;
    }

    .competitor-price {
      color: #dc2626;
      font-weight: 600;
    }
  `}
