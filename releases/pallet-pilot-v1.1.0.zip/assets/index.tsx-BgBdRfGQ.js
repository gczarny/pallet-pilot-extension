import{u as Z,r as m,s as N,j as e,f as I,c as j,d as ee,I as te}from"./index-DCCc4f8X.js";import{g as B,J as ne,i as se}from"./index-D8ms7xkX.js";import"./_commonjsHelpers-Cpj98o6Y.js";async function re(t,a,n){const s=B(t);if(!s?.getBidsApiConfig)return[];let o;s instanceof ne&&(o=s.extractBidsActionId(document));const i=s.getBidsApiConfig(t,{currency:a,language:n,bidsActionId:o});if(!i)return[];try{const l=await fetch(i.url,{method:i.method,headers:i.headers,body:i.method==="POST"?i.body:void 0,credentials:"include"});if(!l.ok)return console.error("[fetchBids] Response not OK:",l.status),[];const u=await l.text();return ae(u)}catch(l){return console.error("[fetchBids] Fetch error:",l),[]}}function ae(t){const a=n=>({id:n.id,auctionId:n.auction_id,userId:n.user_id,userName:n.user_details?.username||n.user_details?.name||"Unknown",bidPrice:n.bid_price,bidTime:n.bid_time,currencyId:n.currency_id,isAutoBid:n.is_auto_bid===1});try{try{const s=JSON.parse(t);if(Array.isArray(s))return s.map(a);if(s.bid&&Array.isArray(s.bid))return s.bid.map(a);if(s.result?.bid&&Array.isArray(s.result.bid))return s.result.bid.map(a);if(s.data&&Array.isArray(s.data))return s.data.map(a)}catch{}const n=t.split(`
`);for(const s of n){const o=s.match(/^\d+:(\{.+\})$/);if(o)try{const i=JSON.parse(o[1]);if(i.result?.bid&&Array.isArray(i.result.bid))return i.result.bid.map(a)}catch{}}return[]}catch(n){return console.error("[fetchBids] Failed to parse bids response:",n),[]}}const ie="7f85c3b96b7f0e4740df33c5cbb862e11a3d68028e",oe=t=>JSON.stringify(["",{children:[["lang",t,"d"],{children:["(website)",{children:["policies",{children:["shipping-policy",{children:["__PAGE__",{},null,null]},null,null]},null,null]},null,null]},null,null]},null,null,!0]),ce=3e3;async function le(t,a){try{const n=`https://jobalots.com/${a}/policies/shipping-policy?currency=${t.toLowerCase()}`,s=JSON.stringify([{url:"/admin-shipping-policy/EU",method:"GET"}]),o=new AbortController,i=setTimeout(()=>o.abort(),ce);try{const l=await fetch(n,{method:"POST",credentials:"include",headers:{Accept:"text/x-component","Content-Type":"text/plain;charset=UTF-8","Next-Action":ie,Referer:n,"Next-Router-State-Tree":oe(a)},body:s,signal:o.signal});if(clearTimeout(i),!l.ok)return null;const u=await l.text();return de(u,t)}catch{return clearTimeout(i),null}}catch{return null}}function de(t,a){try{const n=t.split(`
`);for(const o of n){const i=o.match(/^\d+:(\{.+\})$/);if(i)try{const l=JSON.parse(i[1]);if(l.result?.data?.charge_details){const u=l.result?.data?.currency?.currency;return u&&u.toUpperCase()!==a.toUpperCase()?null:$(l.result.data.charge_details)}}catch{}}if(t.match(/"charge_details"\s*:\s*(\{[^}]+(?:\{[^}]*\}[^}]*)*\})/))try{const o=t.match(/"result"\s*:\s*(\{"data"[\s\S]*?\})\s*\}/);if(o){const i=JSON.parse(o[1]+"}");if(i.data?.charge_details)return $(i.data.charge_details)}}catch{}return null}catch{return null}}function $(t){const a=Object.keys(t).find(l=>l.toLowerCase().includes("poland")||l.toLowerCase().includes("polska"))||Object.keys(t)[0];if(!a)return null;const s=t[a]?.zone_data_manifest_type_wise;if(!Array.isArray(s))return null;const o=s.find(l=>String(l.manifest_type).toLowerCase().includes("pallet"))||s[0];if(!o)return null;const i=pe(o);return i.length===0?null:{tiers:i,zone:a,type:String(o.manifest_type||"Pallets")}}function pe(t){const a=t.data;if(Array.isArray(a)&&a.length>0)return a.map(s=>{const o=String(s.weight_range||""),{min:i,max:l}=D(o),u=Number(s.standard_price??s.price??0);return{min_weight:i,max_weight:l,price:u}}).filter(s=>s.price>0);const n=["zone_charges","charges","tiers"];for(const s of n){const o=t[s];if(Array.isArray(o)&&o.length>0)return o.map(i=>{const l=String(i.weight_range||""),{min:u,max:x}=D(l);return{min_weight:u,max_weight:x,price:Number(i.standard_price??i.price??0)}}).filter(i=>i.price>0)}return[]}function D(t){const a=t.match(/^([\d.]+)\s*-\s*([\d.]+|Or Greater)$/i);if(a){const n=parseFloat(a[1])||0,s=a[2].toLowerCase().includes("greater")?1/0:parseFloat(a[2])||1/0;return{min:n,max:s}}return{min:0,max:1/0}}function ue(t,a){if(!t||t.tiers.length===0)return null;const n=[...t.tiers].sort((s,o)=>s.min_weight-o.min_weight);for(const s of n)if(a>=s.min_weight&&a<=s.max_weight)return s.price;return a>n[n.length-1].max_weight?n[n.length-1].price:null}const he=[{minWeight:0,maxWeight:150,cost:325.07,label:"0-150 kg"},{minWeight:150.01,maxWeight:200,cost:135.07,label:"150-200 kg"},{minWeight:200.01,maxWeight:250,cost:143.51,label:"200-250 kg"},{minWeight:250.01,maxWeight:300,cost:151.96,label:"250-300 kg"},{minWeight:300.01,maxWeight:400,cost:168.84,label:"300-400 kg"},{minWeight:400.01,maxWeight:500,cost:211.07,label:"400-500 kg"},{minWeight:500.01,maxWeight:600,cost:253.29,label:"500-600 kg"},{minWeight:600.01,maxWeight:700,cost:295.51,label:"600-700 kg"},{minWeight:700.01,maxWeight:800,cost:337.74,label:"700-800 kg"},{minWeight:800.01,maxWeight:900,cost:379.96,label:"800-900 kg"},{minWeight:900.01,maxWeight:1e3,cost:422.18,label:"900-1000 kg"},{minWeight:1000.01,maxWeight:1100,cost:527.74,label:"1000-1100 kg"},{minWeight:1100.01,maxWeight:1200,cost:527.74,label:"1100-1200 kg"},{minWeight:1200.01,maxWeight:1300,cost:633.3,label:"1200-1300 kg"},{minWeight:1300.01,maxWeight:1400,cost:633.3,label:"1300-1400 kg"},{minWeight:1400.01,maxWeight:1500,cost:633.3,label:"1400-1500 kg"},{minWeight:1500.01,maxWeight:1600,cost:738.85,label:"1500-1600 kg"},{minWeight:1600.01,maxWeight:1700,cost:738.85,label:"1600-1700 kg"},{minWeight:1700.01,maxWeight:1800,cost:844.41,label:"1700-1800 kg"},{minWeight:1800.01,maxWeight:1900,cost:844.41,label:"1800-1900 kg"},{minWeight:1900.01,maxWeight:2e3,cost:844.41,label:"1900-2000 kg"},{minWeight:2000.01,maxWeight:2100,cost:949.97,label:"2000-2100 kg"},{minWeight:2100.01,maxWeight:2200,cost:949.97,label:"2100-2200 kg"},{minWeight:2200.01,maxWeight:2300,cost:1055.52,label:"2200-2300 kg"},{minWeight:2300.01,maxWeight:2400,cost:1055.52,label:"2300-2400 kg"},{minWeight:2400.01,maxWeight:2500,cost:1055.52,label:"2400-2500 kg"},{minWeight:2500.01,maxWeight:1/0,cost:1477.75,label:"2500+ kg"}],me={PLN:he};function ge(t,a){const n=me[t.toUpperCase()];return!n||n.length===0?null:n.find(o=>a>=o.minWeight&&a<=o.maxWeight)?.cost??null}function fe(t,a){if(!t||t.length===0)return null;const n=[...t].sort((i,l)=>i.minWeight-l.minWeight),s=n.find(i=>a>=i.minWeight&&a<=i.maxWeight);if(s)return s.cost;const o=n[n.length-1];return a>o.maxWeight?o.cost:null}function xe(t,a,n,s,o,i){if(!t||t.source==="none")return null;if(t.currentBid!==void 0&&t.vatRate!==void 0){const l=t.currentBid*t.vatRate,u=s?0:t.shippingCost||0,x=t.currentBid+l+u,c=n>0?x/n:0;return t.shippingCost!==void 0&&t.shippingCost>0||s?e.jsxs("div",{className:"cost-section",children:[e.jsxs("div",{className:"cost-header",children:[e.jsx("span",{className:"cost-title",children:i("fab.cost.title")}),e.jsxs("span",{className:"cost-per-item",children:[j(c,a),e.jsxs("span",{style:{fontSize:"12px",fontWeight:400,marginLeft:"2px"},children:["/",i("fab.units")]})]})]}),e.jsxs("div",{className:"cost-breakdown",children:[e.jsxs("div",{className:"cost-row",children:[e.jsx("span",{className:"cost-row-label",children:i("fab.cost.bid")}),e.jsx("span",{className:"cost-row-value",children:j(t.currentBid||0,a)})]}),e.jsxs("div",{className:"cost-row",children:[e.jsxs("span",{className:"cost-row-label",children:[i("fab.cost.vat")," (",((t.vatRate||0)*100).toFixed(0),"%)"]}),e.jsx("span",{className:"cost-row-value",children:j(l,a)})]}),!s&&e.jsxs("div",{className:"cost-row",children:[e.jsx("span",{className:"cost-row-label",children:i("fab.cost.shipping")}),e.jsx("span",{className:"cost-row-value",children:j(u,a)})]}),e.jsxs("div",{className:"cost-row cost-row-total",children:[e.jsxs("span",{className:"cost-row-label",children:[i("fab.cost.total")," ÷ ",I(n)]}),e.jsx("span",{className:"cost-row-value",children:j(x,a)})]})]}),e.jsxs("label",{className:"cost-checkbox",children:[e.jsx("input",{type:"checkbox",checked:s,onChange:o}),e.jsx("span",{children:i("fab.cost.excludeShipping")})]})]}):e.jsxs("div",{className:"cost-section cost-partial-section",children:[e.jsx("div",{className:"cost-unavailable cost-partial",children:i("fab.cost.partial")}),e.jsxs("label",{className:"cost-checkbox",children:[e.jsx("input",{type:"checkbox",checked:s,onChange:o}),e.jsx("span",{children:i("fab.cost.excludeShipping")})]})]})}return t.source==="partial"&&t.currentBid!==void 0?e.jsxs("div",{className:"cost-section cost-partial-section",children:[e.jsx("div",{className:"cost-unavailable cost-partial",children:i("fab.cost.partial")}),e.jsxs("label",{className:"cost-checkbox",children:[e.jsx("input",{type:"checkbox",checked:s,onChange:o}),e.jsx("span",{children:i("fab.cost.excludeShipping")})]})]}):null}function be({url:t,sku:a,analysis:n,isLoading:s,onAnalysisComplete:o,onRefresh:i,competitorCheck:l,hasCheckedBids:u,onCompetitorCheckComplete:x}){const{t:c}=Z(),[W,_]=m.useState(!1),[b,v]=m.useState(null),[A,z]=m.useState(!1),[g,L]=m.useState(!1),[S,O]=m.useState(!1),[T,P]=m.useState(null);m.useEffect(()=>{if(n&&!u&&!S){const r=B(t)?.scrapePageData(document)??{};R(r.currency,r.language)}},[n,u]);const R=async(h,r)=>{O(!0);try{const p=await N({type:"GET_WATCHLIST"});if(!p.success){console.error("[Panel] Failed to get watchlist"),x(null);return}const d=p.data.watchlist;if(d.length===0){x(null);return}const w=await re(t,h,r),C=d.map(k=>k.odlerId.toLowerCase()),y=w.filter(k=>{const F=String(k.userId).toLowerCase(),U=k.userName.toLowerCase();return C.includes(F)||C.includes(U)}).map(k=>{const F=String(k.userId).toLowerCase(),U=k.userName.toLowerCase(),Q=d.find(X=>{const H=X.odlerId.toLowerCase();return H===F||H===U});return{bid:k,watchlistName:Q?.name||void 0}}),K=w.length>0?w[0]:void 0;x({hasCompetitorBids:y.length>0,competitorBids:y,totalBids:w.length,highestBid:K})}catch(p){console.error("[Panel] Failed to check competitor bids:",p),x(null)}finally{O(!1)}},G=async()=>{if(W)return;_(!0),v(null);const r=B(t)?.scrapePageData(document)??{};let p;if(r.weight&&r.currency&&r.language){const d=await le(r.currency,r.language),w=ue(d,r.weight);if(w!==null)p=w;else{const C=await N({type:"GET_SHIPPING_TIERS",payload:{currency:r.currency}});if(C.success&&C.data.tiers.length>0){const y=fe(C.data.tiers,r.weight);y!==null&&(p=y)}if(p===void 0&&r.currency.toUpperCase()==="PLN"){const y=ge("PLN",r.weight);y!==null&&(p=y)}}}try{const d=await N({type:"DOWNLOAD_AND_ANALYZE_MANIFEST",payload:{url:t,sku:a,title:r.title,imageUrl:r.imageUrl,currency:r.currency,language:r.language,isAuctionEnded:r.isAuctionEnded,weight:r.weight,currentBid:r.currentBid,palletType:r.palletType,location:r.location,shippingCost:p,manifestSku:r.manifestSku}});d.success?(o(d.data.analysis),R(r.currency,r.language)):v(d.error.message)}catch(d){v(d instanceof Error?d.message:c("common.unknownError"))}finally{_(!1)}},V=async()=>{if(!n)return;let h=n.currency;if(!h){const d=await N({type:"GET_SETTINGS"});h=d.success?d.data.settings.defaultCurrency:"PLN"}const r=prompt(c("fab.enterPrice",{currency:h}));if(!r)return;const p=parseFloat(r.replace(",","."));if(isNaN(p)||p<=0){alert(c("fab.invalidPrice"));return}try{const d=await N({type:"SAVE_PURCHASE",payload:{analysisId:n.id,purchasePrice:p}});d.success?i():alert(c("common.error")+": "+d.error.message)}catch{alert(c("fab.saveError"))}};if(s)return e.jsx("div",{className:"panel",children:e.jsxs("div",{className:"loading",children:[e.jsx("div",{className:"spinner"}),e.jsx("p",{children:c("common.loading")})]})});if(W)return e.jsxs("div",{className:"panel",children:[e.jsxs("div",{className:"panel-header",children:[e.jsx("h3",{children:c("fab.title")}),e.jsxs("p",{children:[c("fab.sku"),": ",a]})]}),e.jsxs("div",{className:"loading",children:[e.jsx("div",{className:"spinner"}),e.jsx("p",{children:c("fab.downloadingManifest")})]})]});if(!n)return e.jsxs("div",{className:"panel",children:[e.jsxs("div",{className:"panel-header",children:[e.jsx("h3",{children:c("fab.title")}),e.jsxs("p",{children:[c("fab.sku"),": ",a]})]}),e.jsxs("div",{className:"panel-content",children:[b&&e.jsx("div",{className:"error",children:b}),e.jsx("p",{style:{marginBottom:"16px",color:"#64748b",fontSize:"13px"},children:c("fab.downloadHint")}),e.jsx("button",{className:"btn btn-primary",onClick:G,children:c("fab.downloadManifest")})]})]});const{summary:f}=n,E=n.currency||"PLN";return e.jsxs("div",{className:"panel",children:[e.jsxs("div",{className:"panel-header",children:[e.jsx("h3",{children:n.title?n.title.slice(0,60)+(n.title.length>60?"...":""):c("fab.title")}),e.jsxs("p",{children:[c("fab.sku"),": ",a,n.status==="purchased"&&` • ${c("fab.purchased")}`]})]}),e.jsxs("div",{className:"panel-content",children:[b&&e.jsx("div",{className:"error",children:b}),S&&e.jsx("div",{className:"competitor-checking",children:c("fab.competitors.checking")}),l?.hasCompetitorBids&&(()=>{const h=l.competitorBids.reduce((r,p)=>{const d=p.watchlistName||p.bid.userName;return r[d]||(r[d]=[]),r[d].push(p.bid),r},{});return e.jsxs("div",{className:"competitor-warning",children:[e.jsxs("div",{className:"competitor-warning-title",children:[c("fab.competitors.warningTitle")," (",Object.keys(h).length,")"]}),e.jsx("div",{className:"competitor-users",children:Object.entries(h).map(([r,p])=>e.jsxs("div",{className:"competitor-user",children:[e.jsxs("button",{className:"competitor-user-header",onClick:()=>P(T===r?null:r),children:[e.jsx("span",{className:"competitor-name",children:r}),e.jsxs("span",{className:"competitor-bid-count",children:[p.length," ",p.length===1?c("fab.competitors.offer"):c("fab.competitors.offers"),e.jsx("span",{className:"competitor-expand-icon",children:T===r?"▼":"▶"})]})]}),T===r&&e.jsx("div",{className:"competitor-bids-list",children:p.map((d,w)=>e.jsxs("div",{className:"competitor-bid",children:[e.jsx("span",{className:"competitor-bid-time",children:new Date(d.bidTime).toLocaleString(void 0,{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"})}),e.jsxs("span",{className:"competitor-price",children:[Number(d.bidPrice).toFixed(2)," ",E]})]},w))})]},r))})]})})(),e.jsxs("div",{className:"stat-grid",children:[e.jsxs("div",{className:"stat-item",children:[e.jsx("div",{className:"stat-label",children:c("fab.stats.products")}),e.jsx("div",{className:"stat-value",children:I(f.totalProducts)})]}),e.jsxs("div",{className:"stat-item",children:[e.jsx("div",{className:"stat-label",children:c("fab.stats.items")}),e.jsx("div",{className:"stat-value",children:I(f.totalQuantity)})]}),e.jsxs("div",{className:"stat-item",children:[e.jsx("div",{className:"stat-label",children:c("fab.stats.retailValue")}),e.jsx("div",{className:"stat-value",children:j(f.estimatedValue,E)})]}),e.jsxs("div",{className:"stat-item",children:[e.jsx("div",{className:"stat-label",children:c("fab.stats.avgPrice")}),e.jsx("div",{className:"stat-value",children:j(f.avgPrice,E)})]})]}),xe(n.costData,E,f.totalQuantity,g,()=>L(!g),c),f.categoryBreakdown&&Object.keys(f.categoryBreakdown).length>0&&e.jsxs("div",{className:"breakdown",children:[e.jsxs("div",{className:"breakdown-label",children:[c("fab.categories"),":"]}),e.jsxs("div",{className:"breakdown-list",children:[Object.entries(f.categoryBreakdown).sort((h,r)=>{const p=typeof h[1]=="number"?h[1]:h[1].quantity;return(typeof r[1]=="number"?r[1]:r[1].quantity)-p}).slice(0,A?void 0:5).map(([h,r])=>{const p=typeof r=="number"?r:r.quantity,d=typeof r=="number"?null:r.value;return e.jsxs("div",{className:"breakdown-item",children:[e.jsx("span",{className:"breakdown-name",children:h}),e.jsxs("span",{className:"breakdown-value",children:[I(p)," ",c("fab.units"),d!==null&&d>0&&e.jsxs("span",{className:"breakdown-subvalue",children:[" (",j(d,E),")"]})]})]},h)}),Object.keys(f.categoryBreakdown).length>5&&e.jsx("button",{className:"breakdown-item breakdown-more breakdown-toggle",onClick:()=>z(!A),children:A?c("fab.showLess"):c("fab.showMore",{count:Object.keys(f.categoryBreakdown).length-5})})]})]}),f.conditionBreakdown&&Object.keys(f.conditionBreakdown).length>0&&e.jsxs("div",{className:"breakdown",children:[e.jsxs("div",{className:"breakdown-label",children:[c("fab.productCondition"),":"]}),e.jsx("div",{className:"breakdown-list",children:Object.entries(f.conditionBreakdown).sort((h,r)=>r[1]-h[1]).map(([h,r])=>e.jsxs("div",{className:"breakdown-item",children:[e.jsx("span",{className:"breakdown-name",children:h}),e.jsxs("span",{className:"breakdown-value",children:[I(r)," ",c("fab.units")]})]},h))})]}),n.status!=="purchased"&&e.jsx("button",{className:"btn btn-primary",onClick:V,children:c("fab.markAsPurchased")}),e.jsx("button",{className:"btn btn-secondary",onClick:()=>{const r=B(t)?.scrapePageData(document)??{};R(r.currency,r.language)},disabled:S,children:c(S?"fab.competitors.checking":"fab.competitors.checkButton")}),e.jsx("button",{className:"btn btn-secondary",onClick:G,children:c("fab.refreshManifest")})]})]})}function we(t){try{const a=new URL(t);return`${a.origin}${a.pathname}`}catch{return t}}function ye({url:t,sku:a}){const[n,s]=m.useState(!1),[o,i]=m.useState(null),[l,u]=m.useState(!0),[x,c]=m.useState(null),[W,_]=m.useState(!1),b=we(t);m.useEffect(()=>{v()},[b]);const v=m.useCallback(async()=>{u(!0);try{const g=await N({type:"GET_ANALYSIS_FOR_URL",payload:{url:b}});g.success&&g.data.analysis&&i(g.data.analysis)}catch(g){console.error("[FAB] Error loading analysis:",g)}finally{u(!1)}},[b]),A=m.useCallback(g=>{i(g)},[]),z=()=>{s(!n)};return m.useEffect(()=>{if(!n)return;const g=S=>{S.composedPath().some(P=>P instanceof Element&&P.id==="pallet-pillot-mount")||s(!1)},L=setTimeout(()=>{document.addEventListener("click",g)},0);return()=>{clearTimeout(L),document.removeEventListener("click",g)}},[n]),e.jsxs("div",{className:"fab-container",children:[e.jsxs("button",{className:"fab-button",onClick:z,title:"Pallet Pilot",children:[e.jsx("img",{src:chrome.runtime.getURL("icons/icon-48.png"),alt:"Pallet Pilot",className:"fab-icon"}),o&&e.jsx("div",{className:"fab-badge",children:o.status==="purchased"?e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"}),e.jsx("line",{x1:"3",y1:"6",x2:"21",y2:"6"}),e.jsx("path",{d:"M16 10a4 4 0 0 1-8 0"})]}):e.jsx("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("polyline",{points:"20 6 9 17 4 12"})})})]}),n&&e.jsx(be,{url:b,sku:a,analysis:o,isLoading:l,onAnalysisComplete:A,onRefresh:v,competitorCheck:x,hasCheckedBids:W,onCompetitorCheckComplete:g=>{c(g),_(!0)}})]})}function J(){return typeof chrome<"u"&&typeof chrome.runtime<"u"&&typeof chrome.runtime.id<"u"}se();const M=window.location.href,q=B(M);q&&ke(q);async function ke(t){if(!t||document.getElementById("pallet-pilot-root"))return;const a=await N({type:"GET_SETTINGS"});if(!a.success||!a.data.settings.extensionEnabled)return;const n=a.data.settings,s=t.extractSku(M);if(!s)return;const o=document.createElement("div");o.id="pallet-pilot-root",document.body.appendChild(o);const i=o.attachShadow({mode:"open"}),l=document.createElement("style");l.textContent=Y(n.ui.fabPosition),i.appendChild(l);const u=document.createElement("div");if(u.id="pallet-pillot-mount",i.appendChild(u),ee.createRoot(u).render(e.jsx(m.StrictMode,{children:e.jsx(te,{children:e.jsx(ye,{url:M,sku:s})})})),J())try{chrome.runtime.onMessage.addListener(c=>{J()&&(c.type==="EXTENSION_STATE_CHANGED"&&(c.payload.enabled||o.remove()),c.type==="FAB_POSITION_CHANGED"&&(l.textContent=Y(c.payload.position)))})}catch{}}function Y(t="right"){return`
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    .fab-container {
      position: fixed;
      ${t==="left"?"left: 16px;":"right: 16px;"}
      top: 50%;
      transform: translateY(-50%);
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
    }

    .fab-button {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
      transition: transform 0.2s, box-shadow 0.2s;
    }

    .fab-button:hover {
      transform: scale(1.05);
      box-shadow: 0 6px 16px rgba(102, 126, 234, 0.5);
    }

    .fab-button svg {
      width: 24px;
      height: 24px;
      color: white;
    }

    .fab-icon {
      width: 32px;
      height: 32px;
      object-fit: contain;
    }

    .fab-badge {
      position: absolute;
      top: -4px;
      right: -4px;
      width: 20px;
      height: 20px;
      border-radius: 50%;
      background: #10b981;
      display: flex;
      align-items: center;
      justify-content: center;
      border: 2px solid white;
    }

    .fab-badge svg {
      width: 12px;
      height: 12px;
      color: white;
    }

    .panel {
      position: fixed;
      ${t==="left"?"left: 80px;":"right: 80px;"}
      top: 50%;
      transform: translateY(-50%);
      width: 320px;
      max-height: 80vh;
      background: white;
      border-radius: 20px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
      overflow: hidden;
      z-index: 999998;
    }

    .panel-header {
      padding: 16px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
    }

    .panel-header h3 {
      font-size: 16px;
      font-weight: 600;
      margin-bottom: 4px;
    }

    .panel-header p {
      font-size: 12px;
      opacity: 0.9;
    }

    .panel-content {
      padding: 16px;
      max-height: calc(80vh - 80px);
      overflow-y: auto;
    }

    .stat-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
      margin-bottom: 16px;
    }

    .stat-item {
      background: #f8fafc;
      padding: 12px;
      border-radius: 12px;
    }

    .stat-label {
      font-size: 11px;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 4px;
    }

    .stat-value {
      font-size: 18px;
      font-weight: 600;
      color: #1e293b;
    }

    .btn {
      width: 100%;
      padding: 12px 16px;
      border-radius: 12px;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.2s;
      border: none;
    }

    .btn-primary {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
    }

    .btn-primary:hover {
      opacity: 0.9;
    }

    .btn-primary:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }

    .btn-secondary {
      background: #f1f5f9;
      color: #475569;
      margin-top: 8px;
    }

    .btn-secondary:hover {
      background: #e2e8f0;
    }

    .loading {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 24px;
    }

    .spinner {
      width: 32px;
      height: 32px;
      border: 3px solid #e2e8f0;
      border-top-color: #667eea;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .loading p {
      margin-top: 12px;
      color: #64748b;
      font-size: 14px;
    }

    .error {
      background: #fef2f2;
      color: #dc2626;
      padding: 12px;
      border-radius: 12px;
      font-size: 13px;
      margin-bottom: 12px;
    }

    .categories {
      margin-top: 12px;
    }

    .categories-label {
      font-size: 12px;
      color: #64748b;
      margin-bottom: 6px;
    }

    .categories-list {
      display: flex;
      flex-wrap: wrap;
      gap: 4px;
    }

    .category-tag {
      background: #e0e7ff;
      color: #4338ca;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 11px;
    }

    .breakdown {
      margin-top: 16px;
      padding-top: 12px;
      border-top: 1px solid #e2e8f0;
    }

    .breakdown-label {
      font-size: 12px;
      font-weight: 600;
      color: #475569;
      margin-bottom: 8px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .breakdown-list {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }

    .breakdown-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 13px;
      padding: 6px 8px;
      background: #f8fafc;
      border-radius: 6px;
    }

    .breakdown-name {
      color: #334155;
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      margin-right: 8px;
    }

    .breakdown-value {
      color: #667eea;
      font-weight: 600;
      white-space: nowrap;
    }

    .breakdown-more {
      color: #94a3b8;
      font-style: italic;
      justify-content: center;
    }

    .breakdown-toggle {
      cursor: pointer;
      border: none;
      background: #f1f5f9;
      color: #667eea;
      font-style: normal;
      font-weight: 500;
      transition: background 0.2s;
    }

    .breakdown-toggle:hover {
      background: #e2e8f0;
    }

    .breakdown-subvalue {
      color: #94a3b8;
      font-weight: 400;
      font-size: 11px;
    }

    .competitor-checking {
      background: #f0f9ff;
      color: #0369a1;
      padding: 8px 12px;
      border-radius: 12px;
      font-size: 12px;
      margin-bottom: 12px;
      text-align: center;
    }

    .competitor-warning {
      background: #fef2f2;
      border: 1px solid #fecaca;
      border-radius: 12px;
      padding: 12px;
      margin-bottom: 12px;
    }

    .competitor-warning-title {
      color: #dc2626;
      font-weight: 600;
      font-size: 13px;
      margin-bottom: 8px;
    }

    .competitor-users {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }

    .competitor-user {
      background: white;
      border-radius: 6px;
      overflow: hidden;
    }

    .competitor-user-header {
      width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 8px 10px;
      border: none;
      background: transparent;
      cursor: pointer;
      font-size: 12px;
      transition: background 0.15s;
    }

    .competitor-user-header:hover {
      background: #fef2f2;
    }

    .competitor-name {
      color: #991b1b;
      font-weight: 600;
    }

    .competitor-bid-count {
      color: #dc2626;
      font-size: 11px;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .competitor-expand-icon {
      font-size: 9px;
      color: #9ca3af;
    }

    .competitor-bids-list {
      display: flex;
      flex-direction: column;
      gap: 2px;
      padding: 0 8px 8px 8px;
      max-height: 90px;
      overflow-y: auto;
    }

    .competitor-bid {
      display: flex;
      justify-content: space-between;
      font-size: 11px;
      padding: 4px 8px;
      background: #fef2f2;
      border-radius: 4px;
    }

    .competitor-bid-time {
      color: #6b7280;
    }

    .competitor-price {
      color: #dc2626;
      font-weight: 600;
    }

    /* Cost Breakdown Section */
    .cost-section {
      margin-top: 16px;
      padding: 12px;
      background: linear-gradient(135deg, #f0fdf4 0%, #ecfdf5 100%);
      border: 1px solid #bbf7d0;
      border-radius: 12px;
    }

    .cost-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 10px;
    }

    .cost-title {
      font-size: 12px;
      font-weight: 600;
      color: #166534;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .cost-per-item {
      font-size: 18px;
      font-weight: 700;
      color: #15803d;
    }

    .cost-breakdown {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .cost-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 12px;
      padding: 4px 0;
    }

    .cost-row-label {
      color: #4b5563;
    }

    .cost-row-value {
      color: #1f2937;
      font-weight: 500;
    }

    .cost-row-total {
      border-top: 1px solid #86efac;
      margin-top: 4px;
      padding-top: 8px;
      font-weight: 600;
    }

    .cost-row-total .cost-row-label,
    .cost-row-total .cost-row-value {
      color: #166534;
      font-weight: 600;
    }

    .cost-unavailable {
      margin-top: 16px;
      padding: 10px 12px;
      background: #f8fafc;
      border: 1px dashed #cbd5e1;
      border-radius: 8px;
      color: #64748b;
      font-size: 12px;
      text-align: center;
    }

    .cost-partial {
      background: #fffbeb;
      border-color: #fcd34d;
      color: #92400e;
    }

    .cost-partial-section {
      background: transparent;
      border: none;
      padding: 0;
      margin-top: 16px;
    }

    .cost-partial-section .cost-unavailable {
      margin-top: 0;
      margin-bottom: 0;
    }

    .cost-partial-section .cost-checkbox {
      border-top: none;
      padding-top: 8px;
      margin-top: 8px;
    }

    .cost-checkbox {
      display: flex;
      align-items: center;
      gap: 6px;
      margin-top: 10px;
      padding-top: 10px;
      border-top: 1px solid #d1fae5;
      font-size: 11px;
      color: #6b7280;
      cursor: pointer;
    }

    .cost-checkbox input {
      width: 14px;
      height: 14px;
      accent-color: #667eea;
      cursor: pointer;
    }

    .cost-checkbox span {
      user-select: none;
    }

    /* Custom scrollbar */
    ::-webkit-scrollbar {
      width: 5px;
      height: 5px;
    }

    ::-webkit-scrollbar-track {
      background: transparent;
      border-radius: 3px;
    }

    ::-webkit-scrollbar-thumb {
      background: #d1d5db;
      border-radius: 3px;
      transition: background 0.2s;
    }

    ::-webkit-scrollbar-thumb:hover {
      background: #9ca3af;
    }

    /* Firefox scrollbar */
    * {
      scrollbar-width: thin;
      scrollbar-color: #d1d5db transparent;
    }
  `}
