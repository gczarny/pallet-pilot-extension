import{u as W,r as m,s as k,j as e,f as P,c as _,d as Y,I as K}from"./index--Y47qI15.js";import{g as A,J as Q,i as X}from"./index-CZfXcMal.js";import"./_commonjsHelpers-Cpj98o6Y.js";async function Z(i,c,r){const n=A(i);if(!n?.getBidsApiConfig)return[];let u;n instanceof Q&&(u=n.extractBidsActionId(document));const l=n.getBidsApiConfig(i,{currency:c,language:r,bidsActionId:u});if(!l)return[];try{const f=await fetch(l.url,{method:l.method,headers:l.headers,body:l.method==="POST"?l.body:void 0,credentials:"include"});if(!f.ok)return console.error("[fetchBids] Response not OK:",f.status),[];const h=await f.text();return ee(h)}catch(f){return console.error("[fetchBids] Fetch error:",f),[]}}function ee(i){const c=r=>({id:r.id,auctionId:r.auction_id,userId:r.user_id,userName:r.user_details?.username||r.user_details?.name||"Unknown",bidPrice:r.bid_price,bidTime:r.bid_time,currencyId:r.currency_id,isAutoBid:r.is_auto_bid===1});try{try{const n=JSON.parse(i);if(Array.isArray(n))return n.map(c);if(n.bid&&Array.isArray(n.bid))return n.bid.map(c);if(n.result?.bid&&Array.isArray(n.result.bid))return n.result.bid.map(c);if(n.data&&Array.isArray(n.data))return n.data.map(c)}catch{}const r=i.split(`
`);for(const n of r){const u=n.match(/^\d+:(\{.+\})$/);if(u)try{const l=JSON.parse(u[1]);if(l.result?.bid&&Array.isArray(l.result.bid))return l.result.bid.map(c)}catch{}}return[]}catch(r){return console.error("[fetchBids] Failed to parse bids response:",r),[]}}function te({url:i,sku:c,analysis:r,isLoading:n,onAnalysisComplete:u,onRefresh:l,competitorCheck:f,hasCheckedBids:h,onCompetitorCheckComplete:w}){const{t:s}=W(),[z,C]=m.useState(!1),[b,y]=m.useState(null),[v,L]=m.useState(!1),[p,B]=m.useState(!1),[N,R]=m.useState(null);m.useEffect(()=>{if(r&&!h&&!p){const t=A(i)?.scrapePageData(document)??{};E(t.currency,t.language)}},[r,h]);const E=async(o,t)=>{B(!0);try{const a=await k({type:"GET_WATCHLIST"});if(!a.success){console.error("[Panel] Failed to get watchlist"),w(null);return}const d=a.data.watchlist;if(d.length===0){w(null);return}const j=await Z(i,o,t),D=d.map(g=>g.odlerId.toLowerCase()),U=j.filter(g=>{const O=String(g.userId).toLowerCase(),T=g.userName.toLowerCase();return D.includes(O)||D.includes(T)}).map(g=>{const O=String(g.userId).toLowerCase(),T=g.userName.toLowerCase(),J=d.find(V=>{const M=V.odlerId.toLowerCase();return M===O||M===T});return{bid:g,watchlistName:J?.name||void 0}}),$=j.length>0?j[0]:void 0;w({hasCompetitorBids:U.length>0,competitorBids:U,totalBids:j.length,highestBid:$})}catch(a){console.error("[Panel] Failed to check competitor bids:",a),w(null)}finally{B(!1)}},S=async()=>{C(!0),y(null);const t=A(i)?.scrapePageData(document)??{};try{const a=await k({type:"DOWNLOAD_AND_ANALYZE_MANIFEST",payload:{url:i,sku:c,title:t.title,imageUrl:t.imageUrl,currency:t.currency,language:t.language,isAuctionEnded:t.isAuctionEnded}});a.success?(u(a.data.analysis),E(t.currency,t.language)):y(a.error.message)}catch(a){y(a instanceof Error?a.message:s("common.unknownError"))}finally{C(!1)}},H=async()=>{if(!r)return;let o=r.currency;if(!o){const d=await k({type:"GET_SETTINGS"});o=d.success?d.data.settings.defaultCurrency:"PLN"}const t=prompt(s("fab.enterPrice",{currency:o}));if(!t)return;const a=parseFloat(t.replace(",","."));if(isNaN(a)||a<=0){alert(s("fab.invalidPrice"));return}try{const d=await k({type:"SAVE_PURCHASE",payload:{analysisId:r.id,purchasePrice:a}});d.success?l():alert(s("common.error")+": "+d.error.message)}catch{alert(s("fab.saveError"))}};if(n)return e.jsx("div",{className:"panel",children:e.jsxs("div",{className:"loading",children:[e.jsx("div",{className:"spinner"}),e.jsx("p",{children:s("common.loading")})]})});if(z)return e.jsxs("div",{className:"panel",children:[e.jsxs("div",{className:"panel-header",children:[e.jsx("h3",{children:s("fab.title")}),e.jsxs("p",{children:[s("fab.sku"),": ",c]})]}),e.jsxs("div",{className:"loading",children:[e.jsx("div",{className:"spinner"}),e.jsx("p",{children:s("fab.downloadingManifest")})]})]});if(!r)return e.jsxs("div",{className:"panel",children:[e.jsxs("div",{className:"panel-header",children:[e.jsx("h3",{children:s("fab.title")}),e.jsxs("p",{children:[s("fab.sku"),": ",c]})]}),e.jsxs("div",{className:"panel-content",children:[b&&e.jsx("div",{className:"error",children:b}),e.jsx("p",{style:{marginBottom:"16px",color:"#64748b",fontSize:"13px"},children:s("fab.downloadHint")}),e.jsx("button",{className:"btn btn-primary",onClick:S,children:s("fab.downloadManifest")})]})]});const{summary:x}=r,I=r.currency||"PLN";return e.jsxs("div",{className:"panel",children:[e.jsxs("div",{className:"panel-header",children:[e.jsx("h3",{children:r.title?r.title.slice(0,60)+(r.title.length>60?"...":""):s("fab.title")}),e.jsxs("p",{children:[s("fab.sku"),": ",c,r.status==="purchased"&&` • ${s("fab.purchased")}`]})]}),e.jsxs("div",{className:"panel-content",children:[b&&e.jsx("div",{className:"error",children:b}),p&&e.jsx("div",{className:"competitor-checking",children:s("fab.competitors.checking")}),f?.hasCompetitorBids&&(()=>{const o=f.competitorBids.reduce((t,a)=>{const d=a.watchlistName||a.bid.userName;return t[d]||(t[d]=[]),t[d].push(a.bid),t},{});return e.jsxs("div",{className:"competitor-warning",children:[e.jsxs("div",{className:"competitor-warning-title",children:[s("fab.competitors.warningTitle")," (",Object.keys(o).length,")"]}),e.jsx("div",{className:"competitor-users",children:Object.entries(o).map(([t,a])=>e.jsxs("div",{className:"competitor-user",children:[e.jsxs("button",{className:"competitor-user-header",onClick:()=>R(N===t?null:t),children:[e.jsx("span",{className:"competitor-name",children:t}),e.jsxs("span",{className:"competitor-bid-count",children:[a.length," ",a.length===1?s("fab.competitors.offer"):s("fab.competitors.offers"),e.jsx("span",{className:"competitor-expand-icon",children:N===t?"▼":"▶"})]})]}),N===t&&e.jsx("div",{className:"competitor-bids-list",children:a.map((d,j)=>e.jsxs("div",{className:"competitor-bid",children:[e.jsx("span",{className:"competitor-bid-time",children:new Date(d.bidTime).toLocaleString(void 0,{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"})}),e.jsxs("span",{className:"competitor-price",children:[Number(d.bidPrice).toFixed(2)," ",I]})]},j))})]},t))})]})})(),e.jsxs("div",{className:"stat-grid",children:[e.jsxs("div",{className:"stat-item",children:[e.jsx("div",{className:"stat-label",children:s("fab.stats.products")}),e.jsx("div",{className:"stat-value",children:P(x.totalProducts)})]}),e.jsxs("div",{className:"stat-item",children:[e.jsx("div",{className:"stat-label",children:s("fab.stats.items")}),e.jsx("div",{className:"stat-value",children:P(x.totalQuantity)})]}),e.jsxs("div",{className:"stat-item",children:[e.jsx("div",{className:"stat-label",children:s("fab.stats.retailValue")}),e.jsx("div",{className:"stat-value",children:_(x.estimatedValue,I)})]}),e.jsxs("div",{className:"stat-item",children:[e.jsx("div",{className:"stat-label",children:s("fab.stats.avgPrice")}),e.jsx("div",{className:"stat-value",children:_(x.avgPrice,I)})]})]}),x.categoryBreakdown&&Object.keys(x.categoryBreakdown).length>0&&e.jsxs("div",{className:"breakdown",children:[e.jsxs("div",{className:"breakdown-label",children:[s("fab.categories"),":"]}),e.jsxs("div",{className:"breakdown-list",children:[Object.entries(x.categoryBreakdown).sort((o,t)=>{const a=typeof o[1]=="number"?o[1]:o[1].quantity;return(typeof t[1]=="number"?t[1]:t[1].quantity)-a}).slice(0,v?void 0:5).map(([o,t])=>{const a=typeof t=="number"?t:t.quantity,d=typeof t=="number"?null:t.value;return e.jsxs("div",{className:"breakdown-item",children:[e.jsx("span",{className:"breakdown-name",children:o}),e.jsxs("span",{className:"breakdown-value",children:[P(a)," ",s("fab.units"),d!==null&&d>0&&e.jsxs("span",{className:"breakdown-subvalue",children:[" (",_(d,I),")"]})]})]},o)}),Object.keys(x.categoryBreakdown).length>5&&e.jsx("button",{className:"breakdown-item breakdown-more breakdown-toggle",onClick:()=>L(!v),children:v?s("fab.showLess"):s("fab.showMore",{count:Object.keys(x.categoryBreakdown).length-5})})]})]}),x.conditionBreakdown&&Object.keys(x.conditionBreakdown).length>0&&e.jsxs("div",{className:"breakdown",children:[e.jsxs("div",{className:"breakdown-label",children:[s("fab.productCondition"),":"]}),e.jsx("div",{className:"breakdown-list",children:Object.entries(x.conditionBreakdown).sort((o,t)=>t[1]-o[1]).map(([o,t])=>e.jsxs("div",{className:"breakdown-item",children:[e.jsx("span",{className:"breakdown-name",children:o}),e.jsxs("span",{className:"breakdown-value",children:[P(t)," ",s("fab.units")]})]},o))})]}),r.status!=="purchased"&&e.jsx("button",{className:"btn btn-primary",onClick:H,children:s("fab.markAsPurchased")}),e.jsx("button",{className:"btn btn-secondary",onClick:()=>{const t=A(i)?.scrapePageData(document)??{};E(t.currency,t.language)},disabled:p,children:s(p?"fab.competitors.checking":"fab.competitors.checkButton")}),e.jsx("button",{className:"btn btn-secondary",onClick:S,children:s("fab.refreshManifest")})]})]})}function se(i){try{const c=new URL(i);return`${c.origin}${c.pathname}`}catch{return i}}function re({url:i,sku:c}){const[r,n]=m.useState(!1),[u,l]=m.useState(null),[f,h]=m.useState(!0),[w,s]=m.useState(null),[z,C]=m.useState(!1),b=se(i);m.useEffect(()=>{y()},[b]);const y=m.useCallback(async()=>{h(!0);try{const p=await k({type:"GET_ANALYSIS_FOR_URL",payload:{url:b}});p.success&&p.data.analysis&&l(p.data.analysis)}catch(p){console.error("[FAB] Error loading analysis:",p)}finally{h(!1)}},[b]),v=m.useCallback(p=>{l(p)},[]),L=()=>{n(!r)};return m.useEffect(()=>{if(!r)return;const p=N=>{N.composedPath().some(S=>S instanceof Element&&S.id==="manifest-scout-mount")||n(!1)},B=setTimeout(()=>{document.addEventListener("click",p)},0);return()=>{clearTimeout(B),document.removeEventListener("click",p)}},[r]),e.jsxs("div",{className:"fab-container",children:[e.jsxs("button",{className:"fab-button",onClick:L,title:"Pallet Pilot",children:[e.jsx("img",{src:chrome.runtime.getURL("icons/icon-48.png"),alt:"Pallet Pilot",className:"fab-icon"}),u&&e.jsx("div",{className:"fab-badge",children:u.status==="purchased"?e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"}),e.jsx("line",{x1:"3",y1:"6",x2:"21",y2:"6"}),e.jsx("path",{d:"M16 10a4 4 0 0 1-8 0"})]}):e.jsx("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("polyline",{points:"20 6 9 17 4 12"})})})]}),r&&e.jsx(te,{url:b,sku:c,analysis:u,isLoading:f,onAnalysisComplete:v,onRefresh:y,competitorCheck:w,hasCheckedBids:z,onCompetitorCheckComplete:p=>{s(p),C(!0)}})]})}X();const F=window.location.href,G=A(F);G&&ae(G);async function ae(i){if(!i)return;const c=await k({type:"GET_SETTINGS"});if(!c.success||!c.data.settings.extensionEnabled)return;const r=c.data.settings,n=i.extractSku(F);if(!n){console.error("[ContentScript] Could not extract SKU from URL");return}const u=document.createElement("div");u.id="manifest-scout-root",document.body.appendChild(u);const l=u.attachShadow({mode:"open"}),f=document.createElement("style");f.textContent=q(r.ui.fabPosition),l.appendChild(f);const h=document.createElement("div");h.id="manifest-scout-mount",l.appendChild(h),Y.createRoot(h).render(e.jsx(m.StrictMode,{children:e.jsx(K,{children:e.jsx(re,{url:F,sku:n})})})),chrome.runtime.onMessage.addListener(s=>{s.type==="EXTENSION_STATE_CHANGED"&&(s.payload.enabled||u.remove()),s.type==="FAB_POSITION_CHANGED"&&(f.textContent=q(s.payload.position))})}function q(i="right"){return`
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    .fab-container {
      position: fixed;
      ${i==="left"?"left: 16px;":"right: 16px;"}
      top: 50%;
      transform: translateY(-50%);
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
    }

    .fab-button {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
      transition: transform 0.2s, box-shadow 0.2s;
    }

    .fab-button:hover {
      transform: scale(1.05);
      box-shadow: 0 6px 16px rgba(102, 126, 234, 0.5);
    }

    .fab-button svg {
      width: 24px;
      height: 24px;
      color: white;
    }

    .fab-icon {
      width: 32px;
      height: 32px;
      object-fit: contain;
    }

    .fab-badge {
      position: absolute;
      top: -4px;
      right: -4px;
      width: 20px;
      height: 20px;
      border-radius: 50%;
      background: #10b981;
      display: flex;
      align-items: center;
      justify-content: center;
      border: 2px solid white;
    }

    .fab-badge svg {
      width: 12px;
      height: 12px;
      color: white;
    }

    .panel {
      position: fixed;
      ${i==="left"?"left: 80px;":"right: 80px;"}
      top: 50%;
      transform: translateY(-50%);
      width: 320px;
      background: white;
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
      overflow: hidden;
      z-index: 999998;
    }

    .panel-header {
      padding: 16px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
    }

    .panel-header h3 {
      font-size: 16px;
      font-weight: 600;
      margin-bottom: 4px;
    }

    .panel-header p {
      font-size: 12px;
      opacity: 0.9;
    }

    .panel-content {
      padding: 16px;
    }

    .stat-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
      margin-bottom: 16px;
    }

    .stat-item {
      background: #f8fafc;
      padding: 12px;
      border-radius: 8px;
    }

    .stat-label {
      font-size: 11px;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 4px;
    }

    .stat-value {
      font-size: 18px;
      font-weight: 600;
      color: #1e293b;
    }

    .btn {
      width: 100%;
      padding: 12px 16px;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.2s;
      border: none;
    }

    .btn-primary {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
    }

    .btn-primary:hover {
      opacity: 0.9;
    }

    .btn-primary:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }

    .btn-secondary {
      background: #f1f5f9;
      color: #475569;
      margin-top: 8px;
    }

    .btn-secondary:hover {
      background: #e2e8f0;
    }

    .loading {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 24px;
    }

    .spinner {
      width: 32px;
      height: 32px;
      border: 3px solid #e2e8f0;
      border-top-color: #667eea;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .loading p {
      margin-top: 12px;
      color: #64748b;
      font-size: 14px;
    }

    .error {
      background: #fef2f2;
      color: #dc2626;
      padding: 12px;
      border-radius: 8px;
      font-size: 13px;
      margin-bottom: 12px;
    }

    .categories {
      margin-top: 12px;
    }

    .categories-label {
      font-size: 12px;
      color: #64748b;
      margin-bottom: 6px;
    }

    .categories-list {
      display: flex;
      flex-wrap: wrap;
      gap: 4px;
    }

    .category-tag {
      background: #e0e7ff;
      color: #4338ca;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 11px;
    }

    .breakdown {
      margin-top: 16px;
      padding-top: 12px;
      border-top: 1px solid #e2e8f0;
    }

    .breakdown-label {
      font-size: 12px;
      font-weight: 600;
      color: #475569;
      margin-bottom: 8px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .breakdown-list {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }

    .breakdown-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 13px;
      padding: 6px 8px;
      background: #f8fafc;
      border-radius: 6px;
    }

    .breakdown-name {
      color: #334155;
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      margin-right: 8px;
    }

    .breakdown-value {
      color: #667eea;
      font-weight: 600;
      white-space: nowrap;
    }

    .breakdown-more {
      color: #94a3b8;
      font-style: italic;
      justify-content: center;
    }

    .breakdown-toggle {
      cursor: pointer;
      border: none;
      background: #f1f5f9;
      color: #667eea;
      font-style: normal;
      font-weight: 500;
      transition: background 0.2s;
    }

    .breakdown-toggle:hover {
      background: #e2e8f0;
    }

    .breakdown-subvalue {
      color: #94a3b8;
      font-weight: 400;
      font-size: 11px;
    }

    .competitor-checking {
      background: #f0f9ff;
      color: #0369a1;
      padding: 8px 12px;
      border-radius: 8px;
      font-size: 12px;
      margin-bottom: 12px;
      text-align: center;
    }

    .competitor-warning {
      background: #fef2f2;
      border: 1px solid #fecaca;
      border-radius: 8px;
      padding: 12px;
      margin-bottom: 12px;
    }

    .competitor-warning-title {
      color: #dc2626;
      font-weight: 600;
      font-size: 13px;
      margin-bottom: 8px;
    }

    .competitor-users {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }

    .competitor-user {
      background: white;
      border-radius: 6px;
      overflow: hidden;
    }

    .competitor-user-header {
      width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 8px 10px;
      border: none;
      background: transparent;
      cursor: pointer;
      font-size: 12px;
      transition: background 0.15s;
    }

    .competitor-user-header:hover {
      background: #fef2f2;
    }

    .competitor-name {
      color: #991b1b;
      font-weight: 600;
    }

    .competitor-bid-count {
      color: #dc2626;
      font-size: 11px;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .competitor-expand-icon {
      font-size: 9px;
      color: #9ca3af;
    }

    .competitor-bids-list {
      display: flex;
      flex-direction: column;
      gap: 2px;
      padding: 0 8px 8px 8px;
      max-height: 90px;
      overflow-y: auto;
    }

    .competitor-bid {
      display: flex;
      justify-content: space-between;
      font-size: 11px;
      padding: 4px 8px;
      background: #fef2f2;
      border-radius: 4px;
    }

    .competitor-bid-time {
      color: #6b7280;
    }

    .competitor-price {
      color: #dc2626;
      font-weight: 600;
    }
  `}
